import { createContext } from "react";

const alertaContext = createContext();

export default alertaContext;