import {createContext} from 'react';

const mesaContext = createContext();

export default mesaContext;