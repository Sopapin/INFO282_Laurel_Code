import {createContext} from 'react';

const pedidoContext = createContext();

export default pedidoContext;