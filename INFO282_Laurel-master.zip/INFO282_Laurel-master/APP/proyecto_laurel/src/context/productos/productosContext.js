import { createContext } from "react";

const productosContext = createContext();

export default productosContext;